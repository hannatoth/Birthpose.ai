# BirthPose AI

**Sensor-guided, uncertainty-aware ranking of birthing positions.**
A research platform for testing one hypothesis: *a short, safe, sensor-instrumented
practice session in the clinic can identify which positions suit a particular
mother and baby best, so labour can start from the best-suited positions instead
of defaulting to lying on the back.*

> ⚠️ **Research prototype, not a medical device.** Nothing here has been
> clinically validated. All numbers in this repo come from a *simulator* built on
> stylised assumptions. Do not use it to advise real patients. See
> [docs/ETHICS_REGULATORY.md](docs/ETHICS_REGULATORY.md).

## Why this matters

* Evidence already suggests upright positions can modestly shorten pushing and
  reduce assisted births in women without an epidural, but the Cochrane review rates
  that evidence as low quality, and upright positions were linked with more blood
  loss ≥500 mL and a tendency to more perineal tears
  ([Gupta et al., 2017](https://www.cochrane.org/evidence/CD002006_position-second-stage-labour-women-without-epidural-anaesthesia)).
  So "upright for everyone" is not the answer — **the right position differs per woman.**
* Nobody has a validated way to personalise that choice. That is the gap.

## Why this project?

A too-high intervention rate, little choice of position, trial evidence that the best
position depends on the woman, mature ML and sensor technology, and Hungary's national
insurance data for evaluation and scaling. Aggregated studies in one table: [docs/EVIDENCE_AGGREGATE.md](docs/EVIDENCE_AGGREGATE.md). Full argument, prior work and the gap:
[docs/RATIONALE.md](docs/RATIONALE.md).

## Why personalise? (the evidence)

The best position is not the same for everyone: without an epidural upright
positions help a little, but in the 3,093-woman BUMPES trial first-time mothers **with
an epidural** did *better* lying on their side (41.1% vs 35.2% spontaneous vaginal
birth). Pelvic MRI shows position changes pelvic dimensions by 7–15% and women differ,
and mothers who choose their position report higher satisfaction (5.67 vs 4.72 on a
7-point scale). What is **not** yet proven is that a sensor session can pick her best
positions; that is what this project tests. Full table with sources and limits:
[docs/EVIDENCE.md](docs/EVIDENCE.md).

## Why Hungary

Hungary's state-funded caesarean rate reached a record **42.55% in 2025** (NEAK
data), far above the 10–15% WHO reference range, more than half of vaginal births
involve episiotomy, and in a 2014 survey only about **1 in 4** women in public
hospital care could choose their birth position. Nobody records how many give birth
lying on their back or whether it matters, so the link between position and outcomes
is **unmeasured, not disproven** — which is the point of this project. Hungary's
national health-insurance data (NEAK/TB) are an unusually good base for baselines,
outcome follow-up and cost analysis, but they hold claims data, not position or sensor
data, so those must be collected prospectively. Details, sources and limits:
[docs/HUNGARY.md](docs/HUNGARY.md).

## The idea in one picture

```
 Clinic visit (late pregnancy)                         Labour
 ┌──────────────────────────────┐   ┌────────────────┐  ┌──────────────────────────┐
 │ Sensors on mother (+ Doppler │   │  Safety gate   │  │ Mother + midwife choose  │
 │ for baby) → practice push in │──▶│ (rules, audit- │─▶│ from TOP-3 + reasons;    │
 │ each of 10 poses             │   │  able, first)  │  │ outcomes logged → model  │
 └──────────────────────────────┘   └───────┬────────┘  │ keeps learning (Phase 3) │
                                            ▼           └──────────────────────────┘
                              Uncertainty-aware ranker
                    (duration · fetal safety · perineal · comfort)
                          + abstain → standard of care
```

## What is in this repo

| Component | Path | What it does |
|---|---|---|
| Counterfactual simulator | `src/birthpose/simulation` | Synthetic cohort where the outcome under **every** pose is known, so true regret can be measured |
| Signal features | `src/birthpose/signals/fhr.py` | Transparent FHR features (baseline, variability, decelerations) that run on real CTU-UHB data and on trial traces |
| Real-data bridge | `src/birthpose/data/ctu_uhb.py` | Loader for the open PhysioNet intrapartum CTG database (552 recordings) |
| Safety gate | `src/birthpose/safety` | Deterministic, auditable pose exclusions and whole-recommendation stops |
| Ranker | `src/birthpose/models` | Pose-conditioned gradient-boosted ensembles, inverse-propensity correction, risk-averse scoring, top-3 + abstention |
| Evaluation | `src/birthpose/evaluation` | Regret, top-3 hit rate, baselines, subgroup fairness tables |
| API | `src/birthpose/api` | FastAPI `/v1/recommend` returning ranked poses, reasons and exclusions |
| Study protocol, ethics, funding | `docs/` | The parts a funder and an ethics board actually read |

## Quick start

```bash
pip install -e ".[api,physionet,dev]"
pytest                                    # 8 tests
python scripts/run_experiment.py --n 12000 --sweep --out results
BIRTHPOSE_MODEL=results/ranker.joblib uvicorn birthpose.api.app:app
```

## Her own priorities

Before the session each mother rates 1–5 how much she cares about: a shorter
pushing stage, keeping her baby's heart rate stable, lowering her chance of tears,
and being comfortable. These ratings re-weight the model instantly, so two mothers
with identical readings can get different top-3 lists. Fetal safety has a
**minimum weight of 25%** that no answer can lower, and the safety gate is never
affected by preferences. See `src/birthpose/preferences.py`; the API takes
`"priorities": {"comfort": 5, "short_pushing": 2, ...}` and lists the questions at
`GET /v1/priorities/questions`.

## Simulation results (12,000 simulated women, 1,500 held out)

"Regret" = how much true utility is lost versus the best pose for that woman
(utility scale 0–1; lower is better). Utility blends duration, fetal safety,
perineal trauma and comfort.

| Policy | Regret |
|---|---|
| Everyone semi-recumbent (status quo proxy) | 0.079 |
| Everyone supported squat | 0.049 |
| Random 3 allowed poses | 0.019 |
| "Pick 3 upright poses" heuristic | 0.017 |
| **BirthPose top-3 (best of the three)** | **0.010** |

Effect of how well a clinic practice push predicts labour (`trial_fidelity`):

| Fidelity | 0.0 | 0.2 | 0.4 | 0.6 | 0.8 | 0.9 |
|---|---|---|---|---|---|---|
| Top-3 regret | 0.0161 | 0.0149 | 0.0123 | 0.0103 | 0.0083 | 0.0071 |

**Read these honestly.** The simulator encodes *my assumptions* about physiology, so
beating baselines here proves the pipeline works, not that the idea works in
women. Two takeaways are genuinely useful though:
1. Much of the gain over "everyone upright" comes from **baseline personalisation
   plus the safety gate** (see fidelity 0.0); the sensors add the rest, and the added
   value **scales with how well practice pushes transfer to labour**.
2. That transfer is the single biggest unknown. **Phase 1 of the study measures it
   directly** and decides whether the project continues
   ([docs/STUDY_PROTOCOL.md](docs/STUDY_PROTOCOL.md)).

## Docs

* [Aggregated evidence](docs/EVIDENCE_AGGREGATE.md) · [Rationale](docs/RATIONALE.md) · [Evidence](docs/EVIDENCE.md) · [Why Hungary](docs/HUNGARY.md) · [Architecture](docs/ARCHITECTURE.md) · [Study protocol](docs/STUDY_PROTOCOL.md) ·
  [Data & datasets](docs/DATA.md) · [Ethics & regulatory](docs/ETHICS_REGULATORY.md) ·
  [Model card](docs/MODEL_CARD.md) · [Roadmap & funding brief](docs/FUNDING_BRIEF.md)

## License

MIT for code. The CTU-UHB database has its own non-commercial licence; see
[docs/DATA.md](docs/DATA.md).
