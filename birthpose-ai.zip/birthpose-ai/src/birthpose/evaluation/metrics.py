"""Counterfactual evaluation against simulator ground truth.

Because the simulator knows each patient's true utility under EVERY pose we can
compute real regret, which is impossible on observational clinical data.
(On real data use doubly-robust off-policy evaluation -- see docs/STUDY_PROTOCOL.md.)
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import POSES
from ..models.ranker import PoseRanker, build_features, gate_for_patient

UPRIGHT = ["standing_supported", "supported_squat", "sitting_upright", "kneeling_supported", "hands_and_knees"]


def evaluate_policy(ranker: PoseRanker, patients: pd.DataFrame, long: pd.DataFrame,
                    test_ids: np.ndarray, seed: int = 0) -> tuple[pd.DataFrame, dict]:
    rng = np.random.default_rng(seed)
    sub = long[long.patient_id.isin(test_ids)]
    feats = build_features(patients[patients.patient_id.isin(test_ids)], sub)
    preds = ranker.predict(feats)
    true_u = sub.pivot(index="patient_id", columns="pose", values="utility_true")[POSES]
    pat_idx = patients.set_index("patient_id")
    by_p = {pid: g.to_dict("records") for pid, g in sub.groupby("patient_id")}
    pred_by_p = {pid: g for pid, g in preds.groupby("patient_id")}

    recs = []
    for pid in test_ids:
        gate = gate_for_patient(pat_idx, by_p, pid)
        allowed = gate.allowed
        rec = ranker.recommend(pred_by_p[pid], allowed)
        tu = true_u.loc[pid]
        model_top = [t["pose"] for t in rec["top"]]
        # policy actually shown to mother: abstain -> standard of care only
        shown = [rec["default_pose"]] if (rec["abstain"] and rec["default_pose"]) else model_top
        allowed_list = [z for z in POSES if allowed[z]]
        up_allowed = [z for z in UPRIGHT if allowed[z]]
        rnd = list(rng.choice(allowed_list, size=min(3, len(allowed_list)), replace=False)) if allowed_list else []
        oracle = tu.max()
        oracle_pose = tu.idxmax()
        row = dict(patient_id=pid, oracle=oracle, abstained=rec["abstain"] or gate.global_block != [],
                   n_allowed=len(allowed_list),
                   model_top1=tu[shown[0]] if shown else np.nan,
                   model_best3=tu[shown].max() if shown else np.nan,
                   model_mean3=tu[shown].mean() if shown else np.nan,
                   oracle_in_top3=int(oracle_pose in shown),
                   always_semi=tu["semi_recumbent"], always_squat=tu["supported_squat"],
                   random_best3=tu[rnd].max() if rnd else np.nan,
                   upright_best3=tu[up_allowed[:3]].max() if up_allowed else np.nan)
        recs.append(row)
    df = pd.DataFrame(recs).merge(
        patients[["patient_id", "parity", "bmi", "epidural", "age", "occiput_posterior"]], on="patient_id")
    summary = {
        "n_test": len(df),
        "oracle_mean_utility": df.oracle.mean(),
        "model_top1_regret": (df.oracle - df.model_top1).mean(),
        "model_best3_regret": (df.oracle - df.model_best3).mean(),
        "always_semi_regret": (df.oracle - df.always_semi).mean(),
        "always_squat_regret": (df.oracle - df.always_squat).mean(),
        "random_best3_regret": (df.oracle - df.random_best3).mean(),
        "upright_heuristic_best3_regret": (df.oracle - df.upright_best3).mean(),
        "oracle_in_top3_rate": df.oracle_in_top3.mean(),
        "abstain_rate": df.abstained.mean(),
    }
    return df, summary


def subgroup_table(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["regret_model"] = d.oracle - d.model_best3
    d["regret_semi"] = d.oracle - d.always_semi
    d["bmi_band"] = pd.cut(d.bmi, [0, 18.5, 25, 30, 35, 100], labels=["<18.5", "18.5-25", "25-30", "30-35", "35+"])
    d["age_band"] = pd.cut(d.age, [0, 20, 30, 35, 100], labels=["<20", "20-30", "30-35", "35+"])
    d["parity_g"] = np.where(d.parity == 0, "nulliparous", "multiparous")
    d["epidural_g"] = np.where(d.epidural == 1, "epidural", "no epidural")
    d["op_g"] = np.where(d.occiput_posterior == 1, "OP fetus", "non-OP")
    rows = []
    for col in ["bmi_band", "age_band", "parity_g", "epidural_g", "op_g"]:
        g = d.groupby(col, observed=True).agg(n=("patient_id", "count"), regret_model=("regret_model", "mean"),
                                              regret_semi=("regret_semi", "mean"),
                                              oracle_in_top3=("oracle_in_top3", "mean"),
                                              abstain=("abstained", "mean")).reset_index()
        g.insert(0, "dimension", col)
        g = g.rename(columns={col: "group"})
        rows.append(g)
    return pd.concat(rows, ignore_index=True)
