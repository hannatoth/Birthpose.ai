"""Central configuration: pose catalogue, outcome weights, constants.

The pose parameters below are STYLISED priors used only by the simulator.
They are NOT clinical facts. Real parameters must come from the Phase 1/2
studies described in docs/STUDY_PROTOCOL.md.
"""
from __future__ import annotations

from dataclasses import dataclass, field

POSES: list[str] = [
    "lithotomy_supine",
    "semi_recumbent",
    "left_lateral",
    "right_lateral",
    "side_lying_leg_raised",
    "hands_and_knees",
    "kneeling_supported",
    "sitting_upright",
    "standing_supported",
    "supported_squat",
]
POSE_INDEX = {p: i for i, p in enumerate(POSES)}


@dataclass(frozen=True)
class PoseProfile:
    """Stylised simulator parameters for one pose."""

    outlet_gain: float  # effective pelvic-outlet gain (z-units) vs lithotomy
    aortocaval: float  # supine-hypotension / FHR-stress exposure (0..1)
    mobility_demand: float  # how much hip/knee mobility the pose needs (0..1)
    epidural_penalty: float  # feasibility penalty with epidural (0..1)
    op_benefit: float  # extra benefit when fetus is occiput-posterior
    perineal_risk: float  # additive log-odds for perineal trauma
    gravity: float  # gravity assist (0..1)


POSE_PROFILES: dict[str, PoseProfile] = {
    "lithotomy_supine":      PoseProfile(0.00, 1.00, 0.10, 0.00, 0.00, 0.00, 0.00),
    "semi_recumbent":        PoseProfile(0.20, 0.45, 0.10, 0.00, 0.00, 0.05, 0.25),
    "left_lateral":          PoseProfile(0.35, 0.00, 0.15, 0.05, 0.05, -0.25, 0.10),
    "right_lateral":         PoseProfile(0.35, 0.12, 0.15, 0.05, 0.05, -0.25, 0.10),
    "side_lying_leg_raised": PoseProfile(0.60, 0.05, 0.40, 0.10, 0.10, -0.10, 0.10),
    "hands_and_knees":       PoseProfile(0.50, 0.00, 0.35, 0.20, 0.45, -0.10, 0.30),
    "kneeling_supported":    PoseProfile(0.55, 0.00, 0.45, 0.30, 0.30, -0.05, 0.50),
    "sitting_upright":       PoseProfile(0.50, 0.05, 0.25, 0.15, 0.10, 0.20, 0.70),
    "standing_supported":    PoseProfile(0.60, 0.00, 0.40, 0.45, 0.15, 0.05, 0.90),
    "supported_squat":       PoseProfile(1.00, 0.00, 0.85, 0.55, 0.20, 0.25, 0.85),
}

OUTCOMES = ["log_minutes", "fhr_event", "trauma", "comfort"]


@dataclass
class UtilityWeights:
    """Multi-objective utility. Weights should be elicited from mothers and
    clinicians (see docs/STUDY_PROTOCOL.md, 'Preference elicitation')."""

    duration: float = 0.30
    fetal_safety: float = 0.35
    perineal: float = 0.15
    comfort: float = 0.20

    def normalised(self) -> "UtilityWeights":
        s = self.duration + self.fetal_safety + self.perineal + self.comfort
        return UtilityWeights(self.duration / s, self.fetal_safety / s, self.perineal / s, self.comfort / s)


@dataclass
class SimConfig:
    n_patients: int = 20000
    # How faithfully a clinic-time practice push reflects labour-time pose
    # potential (0 = uninformative, 1 = perfect). THE central scientific
    # unknown; Phase 1 of the study exists to estimate it.
    trial_fidelity: float = 0.6
    seed: int = 7
    logging_policy: str = "clinical"  # "clinical" (confounded) | "randomized_safe"


@dataclass
class RankerConfig:
    n_ensemble: int = 5
    kappa: float = 0.5  # uncertainty penalty on expected utility
    top_k: int = 3
    abstain_margin: float = 0.01  # min gain over default pose to personalise
    default_pose: str = "semi_recumbent"
    ipw_clip: float = 20.0
    weights: UtilityWeights = field(default_factory=UtilityWeights)
