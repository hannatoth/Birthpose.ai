"""Decision-support API (research prototype -- NOT a medical device).

    BIRTHPOSE_MODEL=results/ranker.joblib uvicorn birthpose.api.app:app
"""
from __future__ import annotations

import os

import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from ..config import POSES
from ..models.ranker import TRIAL_COLS, PoseRanker, build_features
from ..preferences import QUESTIONS, weights_from_priorities
from ..safety.gate import evaluate as gate_evaluate

app = FastAPI(title="BirthPose AI", version="0.1.0",
              description="Research prototype. Not a medical device. Clinician oversight required.")
_ranker: PoseRanker | None = None


def get_ranker() -> PoseRanker:
    global _ranker
    if _ranker is None:
        path = os.environ.get("BIRTHPOSE_MODEL", "results/ranker.joblib")
        if not os.path.exists(path):
            raise HTTPException(503, f"model not found at {path}")
        _ranker = PoseRanker.load(path)
    return _ranker


class Baseline(BaseModel):
    age: float = Field(ge=14, le=55)
    bmi: float = Field(ge=14, le=70)
    height_cm: float = Field(ge=130, le=210)
    parity: int = Field(ge=0, le=15)
    ga_weeks: float = Field(ge=30, le=44)
    est_fetal_weight_g: float = Field(ge=1000, le=6000)
    occiput_posterior: int = Field(ge=0, le=1)
    station: float = Field(ge=-5, le=5)
    epidural: int = Field(ge=0, le=1)
    hip_mobility: float = Field(ge=0, le=1)
    back_pain: float = Field(ge=0, le=1)
    knee_limitation: int = Field(ge=0, le=1)
    hypertensive: int = Field(ge=0, le=1)
    pelvimetry_z: float = Field(ge=-5, le=5)


class PoseTrial(BaseModel):
    pose: str
    peak_iap_mmhg: float
    pelvic_floor_descent_mm: float
    maternal_hr_delta_bpm: float
    maternal_spo2_nadir: float
    fhr_baseline_delta_bpm: float
    fhr_decel_count: float
    posture_sway_rms_mm: float
    hold_duration_s: float
    comfort_vas: float


class Request(BaseModel):
    baseline: Baseline
    trials: list[PoseTrial]
    # Mother's own priorities, each rated 1-5: short_pushing, baby_safety, avoid_tears, comfort
    priorities: dict[str, int] | None = None


@app.get("/v1/priorities/questions")
def priorities_questions():
    return {"scale": "1 (not important) to 5 (very important)", "questions": QUESTIONS}


@app.get("/healthz")
def healthz():
    return {"status": "ok", "disclaimer": "Research prototype; not a medical device."}


@app.post("/v1/recommend")
def recommend(req: Request):
    ranker = get_ranker()
    for t in req.trials:
        if t.pose not in POSES:
            raise HTTPException(422, f"unknown pose {t.pose}")
    if len({t.pose for t in req.trials}) < 5:
        raise HTTPException(422, "at least 5 distinct poses must be trialled")
    base = req.baseline.model_dump()
    pat = pd.DataFrame([{**base, "patient_id": 0}])
    long = pd.DataFrame([{"patient_id": 0, **t.model_dump()} for t in req.trials])
    # Poses that were not trialled cannot be recommended (gate marks them disallowed).
    feats = build_features(pat, long)
    try:
        w = weights_from_priorities(req.priorities) if req.priorities else None
    except ValueError as e:
        raise HTTPException(422, str(e)) from e
    preds = ranker.predict(feats, w)
    trials = {t.pose: {c: getattr(t, c) for c in TRIAL_COLS} for t in req.trials}
    gate = gate_evaluate(pd.Series(base), trials)
    if gate.global_block:
        return {"status": "withheld", "reasons": gate.global_block,
                "message": "No automated recommendation; clinician-led decision."}
    rec = ranker.recommend(preds, gate.allowed)
    return {"status": "abstain" if rec["abstain"] else "ok", **rec,
            "excluded": {k: v for k, v in gate.reasons.items() if v},
            "priorities_used": req.priorities or "default weights",
            "disclaimer": "Decision support only. The mother's preference and the clinician's judgement prevail."}
