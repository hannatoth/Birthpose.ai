"""Fetal-heart-rate (FHR) feature extraction.

Works on any 4 Hz FHR series: the CTU-UHB intrapartum database (PhysioNet),
or a Doppler/NIR trace recorded during a clinic practice push.
Deliberately simple, transparent, FIGO-inspired features (not a diagnosis).
"""
from __future__ import annotations

import numpy as np


def clean_fhr(fhr: np.ndarray, fs: float = 4.0) -> np.ndarray:
    """Mark physiologically impossible values as NaN and interpolate short gaps."""
    x = np.asarray(fhr, dtype=float).copy()
    x[(x < 50) | (x > 220)] = np.nan
    idx = np.arange(len(x))
    ok = ~np.isnan(x)
    if ok.sum() < 2:
        return x
    # interpolate gaps up to 15 s only
    max_gap = int(15 * fs)
    filled = np.interp(idx, idx[ok], x[ok])
    gap_start = None
    for i, v in enumerate(ok):
        if not v and gap_start is None:
            gap_start = i
        if (v or i == len(ok) - 1) and gap_start is not None:
            end = i if v else i + 1
            if end - gap_start > max_gap:
                filled[gap_start:end] = np.nan
            gap_start = None
    return filled


def fhr_features(fhr: np.ndarray, fs: float = 4.0) -> dict[str, float]:
    x = clean_fhr(fhr, fs)
    valid = ~np.isnan(x)
    if valid.mean() < 0.5:
        return dict(valid_fraction=float(valid.mean()), baseline=np.nan, stv=np.nan,
                    ltv=np.nan, n_decels=np.nan, decel_area=np.nan, tachy_frac=np.nan, brady_frac=np.nan)
    xv = x[valid]
    # baseline: mode-like estimate from the 10 bpm-wide histogram bin with most mass
    hist, edges = np.histogram(xv, bins=np.arange(xv.min(), xv.max() + 5, 5))
    b = int(np.argmax(hist))
    baseline = float(np.mean(xv[(xv >= edges[b]) & (xv < edges[b + 1] + 1e-9)]))
    # short-term variability: mean abs successive difference of 2.5-s epochs
    step = max(int(2.5 * fs), 1)
    ep = np.array([np.nanmean(x[i:i + step]) for i in range(0, len(x) - step, step)])
    ep = ep[~np.isnan(ep)]
    stv = float(np.mean(np.abs(np.diff(ep)))) if len(ep) > 2 else np.nan
    # long-term variability: range within 1-min windows
    w = int(60 * fs)
    ltv_vals = [np.nanmax(x[i:i + w]) - np.nanmin(x[i:i + w])
                for i in range(0, len(x) - w, w) if np.sum(~np.isnan(x[i:i + w])) > w // 2]
    ltv = float(np.mean(ltv_vals)) if ltv_vals else np.nan
    # decelerations: >=15 bpm below baseline for >=15 s
    below = np.where(np.isnan(x), False, x < baseline - 15)
    n_dec, area, run = 0, 0.0, 0
    for i, flag in enumerate(below):
        if flag:
            run += 1
            area += (baseline - x[i]) / fs
        if (not flag or i == len(below) - 1) and run:
            if run / fs >= 15:
                n_dec += 1
            run = 0
    return dict(valid_fraction=float(valid.mean()), baseline=baseline, stv=stv, ltv=ltv,
                n_decels=float(n_dec), decel_area=float(area),
                tachy_frac=float(np.mean(xv > 160)), brady_frac=float(np.mean(xv < 110)))
