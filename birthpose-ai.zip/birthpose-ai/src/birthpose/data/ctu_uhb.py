"""Loader for the open CTU-UHB intrapartum CTG database (PhysioNet).

Download (non-commercial licence, cite Chudacek et al. 2014):
    https://physionet.org/content/ctu-uhb-ctgdb/1.0.0/

Used here to (a) validate/benchmark the FHR feature extractor on REAL fetal
signals and (b) pre-train a fetal-stress embedding. It contains NO maternal
position labels, so it cannot train the pose model itself.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..signals.fhr import fhr_features


def load_record(path: str | Path):
    """Return (fhr, uc, header_comments) for record path WITHOUT extension."""
    import wfdb  # optional dependency

    rec = wfdb.rdrecord(str(path))
    sig = rec.p_signal
    return sig[:, 0], sig[:, 1], rec.comments


def parse_comments(comments: list[str]) -> dict[str, float]:
    out = {}
    for c in comments:
        c = c.strip("#").strip()
        if "  " in c or " " in c:
            parts = c.split()
            try:
                out[" ".join(parts[:-1])] = float(parts[-1])
            except ValueError:
                pass
    return out


def build_feature_table(db_dir: str | Path, last_minutes: int = 30, fs: float = 4.0) -> pd.DataFrame:
    """FHR features from the last `last_minutes` of each recording + outcomes (pH, Apgar)."""
    rows = []
    for hea in sorted(Path(db_dir).glob("*.hea")):
        fhr, _, comments = load_record(hea.with_suffix(""))
        tail = fhr[-int(last_minutes * 60 * fs):]
        feats = fhr_features(tail, fs)
        meta = parse_comments(comments)
        rows.append({"record": hea.stem, **feats, **meta})
    return pd.DataFrame(rows)
