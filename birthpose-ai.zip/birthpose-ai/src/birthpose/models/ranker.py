"""Pose-conditioned, uncertainty-aware outcome model + top-k ranker.

Pipeline
--------
1. Features per (patient, pose): baseline clinical covariates, pose identity,
   that pose's practice-push sensor features, and the same features *relative
   to the patient's own mean across poses* (within-person contrast).
2. Training rows are only the pose actually used in labour (counterfactuals are
   never observed in real life). Selection bias from the clinical logging
   policy is corrected with inverse-propensity weights (propensity estimated
   from baseline covariates, clipped and self-normalised).
3. Four outcome models (duration, fetal-heart-rate event, perineal trauma,
   comfort) x a bootstrap ensemble -> mean and spread of expected utility.
4. Conservative score = mean - kappa * std  (risk-averse; penalises poses the
   model is unsure about). Top-k after the deterministic safety gate.
5. Abstain (recommend the standard-of-care pose) when personalisation does not
   beat the default by a margin.
"""
from __future__ import annotations

from dataclasses import dataclass

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from ..config import POSE_INDEX, RankerConfig, UtilityWeights
from ..safety.gate import evaluate as gate_evaluate
from ..simulation.generator import utility

BASELINE_COLS = ["age", "bmi", "height_cm", "parity", "ga_weeks", "est_fetal_weight_g",
                 "occiput_posterior", "station", "epidural", "hip_mobility", "back_pain",
                 "knee_limitation", "hypertensive", "pelvimetry_z"]
TRIAL_COLS = ["peak_iap_mmhg", "pelvic_floor_descent_mm", "maternal_hr_delta_bpm",
              "maternal_spo2_nadir", "fhr_baseline_delta_bpm", "fhr_decel_count",
              "posture_sway_rms_mm", "hold_duration_s", "comfort_vas"]


def build_features(patients: pd.DataFrame, long: pd.DataFrame) -> pd.DataFrame:
    """One row per (patient, pose) in `long`."""
    df = long[["patient_id", "pose"] + TRIAL_COLS].copy()
    mean_by_patient = df.groupby("patient_id")[TRIAL_COLS].transform("mean")
    rel = (df[TRIAL_COLS] - mean_by_patient).add_suffix("_rel")
    df = pd.concat([df, rel], axis=1)
    df["pose_idx"] = df["pose"].map(POSE_INDEX).astype(int)
    df = df.merge(patients[["patient_id"] + BASELINE_COLS], on="patient_id", how="left")
    return df


def feature_cols() -> list[str]:
    return BASELINE_COLS + TRIAL_COLS + [c + "_rel" for c in TRIAL_COLS] + ["pose_idx"]


@dataclass
class _Ens:
    models: list


class PoseRanker:
    def __init__(self, cfg: RankerConfig | None = None, seed: int = 0):
        self.cfg = cfg or RankerConfig()
        self.seed = seed
        self.ens: dict[str, _Ens] = {}
        self.propensity_model = None
        self.scaler = None

    # ---------------- training ----------------
    def _fit_propensity(self, patients: pd.DataFrame, obs: pd.DataFrame) -> np.ndarray:
        X = patients.set_index("patient_id").loc[obs.patient_id, BASELINE_COLS].values
        self.scaler = StandardScaler().fit(X)
        y = obs.pose.map(POSE_INDEX).values
        self.propensity_model = LogisticRegression(max_iter=300).fit(self.scaler.transform(X), y)
        proba = self.propensity_model.predict_proba(self.scaler.transform(X))
        cls = list(self.propensity_model.classes_)
        p = np.array([proba[i, cls.index(c)] for i, c in enumerate(y)])
        return p

    def fit(self, patients: pd.DataFrame, long: pd.DataFrame, obs: pd.DataFrame) -> "PoseRanker":
        rng = np.random.default_rng(self.seed)
        feats = build_features(patients, long)
        keys = obs[["patient_id", "pose"]]
        train = keys.merge(feats, on=["patient_id", "pose"], how="left")
        prop = self._fit_propensity(patients, obs)
        w = np.clip(1.0 / np.clip(prop, 1e-3, 1), 1, self.cfg.ipw_clip)
        w = w / w.mean()
        X = train[feature_cols()].values
        targets = {"log_minutes": obs.log_minutes.values, "comfort": obs.comfort.values,
                   "fhr_event": obs.fhr_event.values, "trauma": obs.trauma.values}
        n = len(X)
        for name, y in targets.items():
            models = []
            for k in range(self.cfg.n_ensemble):
                idx = rng.integers(0, n, n)
                if name in ("fhr_event", "trauma"):
                    m = HistGradientBoostingClassifier(max_iter=120, learning_rate=0.06, max_depth=4,
                                                       l2_regularization=1.0, random_state=self.seed + k)
                else:
                    m = HistGradientBoostingRegressor(max_iter=160, learning_rate=0.06, max_depth=4,
                                                      l2_regularization=1.0, random_state=self.seed + k)
                m.fit(X[idx], y[idx], sample_weight=w[idx])
                models.append(m)
            self.ens[name] = _Ens(models)
        return self

    # ---------------- inference ----------------
    def predict(self, feats: pd.DataFrame, weights: UtilityWeights | None = None) -> pd.DataFrame:
        weights = weights or self.cfg.weights
        X = feats[feature_cols()].values
        K = self.cfg.n_ensemble
        utils = np.zeros((len(X), K))
        comp = {k: np.zeros(len(X)) for k in ("minutes", "fhr_p", "trauma_p", "comfort")}
        for k in range(K):
            minutes = np.exp(self.ens["log_minutes"].models[k].predict(X))
            fhr = self.ens["fhr_event"].models[k].predict_proba(X)[:, 1]
            tr = self.ens["trauma"].models[k].predict_proba(X)[:, 1]
            cm = np.clip(self.ens["comfort"].models[k].predict(X), 0, 10)
            utils[:, k] = utility(minutes, fhr, tr, cm, weights)
            for key, v in zip(comp, (minutes, fhr, tr, cm)):
                comp[key] += v / K
        out = feats[["patient_id", "pose"]].copy()
        out["u_mean"], out["u_std"] = utils.mean(1), utils.std(1)
        out["score"] = out.u_mean - self.cfg.kappa * out.u_std
        for key, v in comp.items():
            out["pred_" + key] = v
        return out

    def recommend(self, preds: pd.DataFrame, allowed: dict[str, bool]) -> dict:
        """Top-k poses for ONE patient (preds has one row per pose)."""
        cfg = self.cfg
        p = preds.set_index("pose")
        ok = p[[allowed.get(z, False) for z in p.index]].sort_values("score", ascending=False)
        default = cfg.default_pose if allowed.get(cfg.default_pose, False) else None
        top = ok.head(cfg.top_k)
        abstain = False
        if default is not None and len(top):
            gain = top.score.iloc[0] - p.loc[default, "score"]
            abstain = bool(gain < cfg.abstain_margin)
        return {"abstain": abstain, "default_pose": default,
                "top": [{"pose": z, "expected_utility": float(r.u_mean), "uncertainty": float(r.u_std),
                         "score": float(r.score), "pred_second_stage_min": float(r.pred_minutes),
                         "pred_fhr_event_risk": float(r.pred_fhr_p),
                         "pred_perineal_trauma_risk": float(r.pred_trauma_p),
                         "pred_comfort_0_10": float(r.pred_comfort)} for z, r in top.iterrows()]}

    def save(self, path: str):
        joblib.dump(self, path)

    @staticmethod
    def load(path: str) -> "PoseRanker":
        return joblib.load(path)


def gate_for_patient(patients_idx: pd.DataFrame, long_by_patient: dict, pid: int):
    pat = patients_idx.loc[pid]
    rows = long_by_patient[pid]
    trials = {r["pose"]: {c: r[c] for c in TRIAL_COLS} for r in rows}
    return gate_evaluate(pat, trials)
