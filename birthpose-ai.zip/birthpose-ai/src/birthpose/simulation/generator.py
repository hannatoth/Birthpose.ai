"""Synthetic cohort generator with *known counterfactuals*.

Why simulate? In real data only the pose actually used in labour is observed.
Here we generate the outcome under EVERY pose, so we can measure true regret
of a recommender -- something impossible with observational data alone.

Everything is stylised; see config.POSE_PROFILES. Use for engineering,
stress-testing and power analysis, never as clinical evidence.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..config import POSES, POSE_PROFILES, SimConfig, UtilityWeights


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def sample_patients(n: int, rng: np.random.Generator) -> pd.DataFrame:
    age = np.clip(rng.normal(29.6, 5.2, n), 18, 46)
    bmi = np.clip(rng.lognormal(np.log(25.5), 0.18, n), 17, 52)
    height = np.clip(rng.normal(165, 7, n), 145, 190)
    parity = rng.choice([0, 1, 2, 3], n, p=[0.46, 0.34, 0.14, 0.06])
    ga = np.clip(rng.normal(39.6, 1.0, n), 37, 42)
    pelvic_z = rng.normal(0, 1, n) - 0.25 * (height < 155)  # latent true
    efw = np.clip(rng.normal(3400 + 60 * (ga - 39.6) * 3 + 8 * (bmi - 25), 430, n), 2200, 4900)
    op = rng.random(n) < (0.10 + 0.03 * (bmi > 32))
    station = rng.normal(0.5, 1.0, n)
    epidural = rng.random(n) < 0.40
    hip_mob = rng.beta(5, 2, n)
    back_pain = rng.beta(2, 5, n)
    knee_lim = rng.random(n) < 0.08
    hypert = rng.random(n) < 0.08
    pelvimetry_z = pelvic_z + rng.normal(0, 0.6, n)  # what the clinic can measure
    return pd.DataFrame(
        dict(age=age, bmi=bmi, height_cm=height, parity=parity, ga_weeks=ga,
             est_fetal_weight_g=efw, occiput_posterior=op.astype(int), station=station,
             epidural=epidural.astype(int), hip_mobility=hip_mob, back_pain=back_pain,
             knee_limitation=knee_lim.astype(int), hypertensive=hypert.astype(int),
             pelvimetry_z=pelvimetry_z, _pelvic_z=pelvic_z)
    )


def pose_truth(p: pd.DataFrame, rng: np.random.Generator) -> dict[str, dict[str, np.ndarray]]:
    """Latent labour-time outcomes of each patient under each pose."""
    n = len(p)
    bmi_z = (p.bmi.values - 25.5) / 5.5
    ga_z = p.ga_weeks.values - 39.6
    efw_z = (p.est_fetal_weight_g.values - 3400) / 430
    nulli = (p.parity.values == 0).astype(float)
    # personal pose preference (random effect) -- what comfort trials capture
    pref = rng.normal(0, 1.0, (n, len(POSES)))
    out: dict[str, dict[str, np.ndarray]] = {}
    for j, pose in enumerate(POSES):
        pr = POSE_PROFILES[pose]
        feas = 1.0 - pr.epidural_penalty * p.epidural.values
        feas *= 1.0 - pr.mobility_demand * (1 - p.hip_mobility.values) * 0.9
        feas *= 1.0 - 0.6 * pr.mobility_demand * p.knee_limitation.values
        feas = np.clip(feas, 0.05, 1.0)
        gain = pr.outlet_gain * feas + pr.op_benefit * p.occiput_posterior.values * feas
        eff_outlet = p._pelvic_z.values + gain  # larger = easier birth
        base = np.where(nulli == 1, 55.0, 20.0)
        log_min = (np.log(base) + 0.16 * efw_z + 0.25 * p.occiput_posterior.values
                   - 0.20 * eff_outlet - 0.10 * pr.gravity * (1 - 0.7 * p.epidural.values)
                   - 0.05 * p.station.values + rng.normal(0, 0.18, n))
        fhr_logit = (-3.0 + pr.aortocaval * (0.7 * bmi_z + 0.5 * ga_z + 0.6)
                     + 0.6 * p.hypertensive.values - 0.25 * eff_outlet + 0.2 * np.exp(log_min) / 60)
        trauma_logit = (-1.6 + pr.perineal_risk + 0.45 * efw_z + 0.35 * nulli
                        - 0.15 * eff_outlet)
        comfort = np.clip(6.2 - 2.0 * p.back_pain.values * pr.mobility_demand
                          - 1.4 * (1 - feas) + 0.9 * pref[:, j] + 0.5 * pr.gravity
                          - 0.8 * pr.aortocaval * (bmi_z > 1) + rng.normal(0, 0.4, n), 0, 10)
        out[pose] = dict(log_minutes=log_min, fhr_p=_sigmoid(fhr_logit),
                         trauma_p=_sigmoid(trauma_logit), comfort=comfort,
                         eff_outlet=eff_outlet, feas=feas, pref=pref[:, j])
    return out


def utility(minutes, fhr_p, trauma_p, comfort, w: UtilityWeights) -> np.ndarray:
    w = w.normalised()
    return (w.duration * (1 - np.clip(minutes / 120.0, 0, 1))
            + w.fetal_safety * (1 - np.clip(fhr_p * 4, 0, 1))
            + w.perineal * (1 - np.clip(trauma_p * 2, 0, 1))
            + w.comfort * comfort / 10.0)


def trial_signals(p: pd.DataFrame, truth, fidelity: float,
                  rng: np.random.Generator) -> dict[str, dict[str, np.ndarray]]:
    """Sensor readings from a clinic-time practice push in each pose.

    reading = fidelity * latent + sqrt(1 - fidelity^2) * noise, so `fidelity`
    directly controls how transferable the trial is to real labour.
    """
    n = len(p)
    f, g = fidelity, np.sqrt(max(1 - fidelity ** 2, 0.0))
    z = lambda v: (v - v.mean()) / (v.std() + 1e-9)
    sig: dict[str, dict[str, np.ndarray]] = {}
    for pose in POSES:
        t = truth[pose]
        eff = z(t["eff_outlet"])
        cmf = z(t["comfort"])
        risk = z(np.log(t["fhr_p"]))
        mix = lambda latent, scale, mu: mu + scale * (f * latent + g * rng.normal(0, 1, n))
        sig[pose] = dict(
            peak_iap_mmhg=mix(0.6 * eff + 0.4 * cmf, 9.0, 55.0),
            pelvic_floor_descent_mm=mix(eff, 2.5, 9.0),
            maternal_hr_delta_bpm=mix(-0.4 * cmf - 0.3 * eff, 6.0, 18.0),
            maternal_spo2_nadir=np.clip(mix(-0.25 * risk, 1.2, 96.5), 85, 100),
            fhr_baseline_delta_bpm=mix(-0.7 * risk, 4.0, -2.0),
            fhr_decel_count=np.clip(np.round(mix(0.8 * risk, 0.9, 0.6)), 0, 8),
            posture_sway_rms_mm=np.clip(mix(-0.5 * cmf, 2.0, 6.0), 0.5, None),
            hold_duration_s=np.clip(mix(0.7 * cmf + 0.3 * eff, 6.0, 40.0), 5, 90),
            comfort_vas=np.clip(mix(cmf, 1.6, 6.0), 0, 10),
        )
    return sig


def logging_policy(p: pd.DataFrame, util_true: np.ndarray, rng: np.random.Generator,
                   policy: str) -> tuple[np.ndarray, np.ndarray]:
    """Which pose was actually used in labour (+ the true propensity)."""
    n, k = util_true.shape
    if policy == "randomized_safe":
        probs = np.full((n, k), 1.0 / k)
    else:  # confounded clinical habit: mostly recumbent, sicker/obese -> more recumbent
        logits = np.zeros((n, k))
        idx = {pz: i for i, pz in enumerate(POSES)}
        logits[:, idx["semi_recumbent"]] += 2.2
        logits[:, idx["lithotomy_supine"]] += 1.4 + 0.5 * p.epidural.values
        logits[:, idx["left_lateral"]] += 0.4
        logits[:, idx["supported_squat"]] += 1.2 * (1 - p.epidural.values) * (p.parity.values > 0)
        logits[:, idx["standing_supported"]] += 0.6 * (1 - p.epidural.values)
        logits[:, idx["hands_and_knees"]] += 0.3 + 0.8 * p.occiput_posterior.values
        probs = np.exp(logits - logits.max(1, keepdims=True))
        probs /= probs.sum(1, keepdims=True)
    c = probs.cumsum(1)
    choice = (rng.random((n, 1)) > c).sum(1)
    choice = np.minimum(choice, k - 1)
    return choice, probs[np.arange(n), choice]


def simulate(cfg: SimConfig | None = None, weights: UtilityWeights | None = None):
    """Returns (patients, trial_wide, truth_long, logged) DataFrames."""
    cfg = cfg or SimConfig()
    weights = weights or UtilityWeights()
    rng = np.random.default_rng(cfg.seed)
    p = sample_patients(cfg.n_patients, rng)
    truth = pose_truth(p, rng)
    sig = trial_signals(p, truth, cfg.trial_fidelity, rng)
    n = len(p)

    U = np.column_stack([
        utility(np.exp(truth[z]["log_minutes"]), truth[z]["fhr_p"], truth[z]["trauma_p"],
                truth[z]["comfort"], weights) for z in POSES])
    choice, prop = logging_policy(p, U, rng, cfg.logging_policy)

    rows = []
    for j, pose in enumerate(POSES):
        d = pd.DataFrame({"patient_id": np.arange(n), "pose": pose, "utility_true": U[:, j]})
        for k in ("log_minutes", "fhr_p", "trauma_p", "comfort"):
            d[k + "_true"] = truth[pose][k]
        for k, v in sig[pose].items():
            d[k] = v
        rows.append(d)
    long = pd.concat(rows, ignore_index=True)

    # observed labour outcome only for the pose actually used
    obs = long[long.pose.values == np.array(POSES)[choice][long.patient_id.values]].copy()
    obs = obs.sort_values("patient_id").reset_index(drop=True)
    obs["propensity"] = prop
    obs["fhr_event"] = (rng.random(n) < obs["fhr_p_true"].values).astype(int)
    obs["trauma"] = (rng.random(n) < obs["trauma_p_true"].values).astype(int)
    obs["log_minutes"] = obs["log_minutes_true"].values
    obs["comfort"] = obs["comfort_true"].values
    patients = p.drop(columns=["_pelvic_z"]).assign(patient_id=np.arange(n))
    return patients, long, obs
