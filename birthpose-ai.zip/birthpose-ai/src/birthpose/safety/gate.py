"""Deterministic safety gate. Runs BEFORE and independently of the ML model.

Design principle: the model can only choose among poses the gate allows, and
every exclusion is explained in human-readable text. The gate is rule-based on
purpose so it can be audited, versioned and certified separately (IEC 62304).
Thresholds below are illustrative placeholders for clinician sign-off.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from ..config import POSE_PROFILES


@dataclass
class GateResult:
    allowed: dict[str, bool] = field(default_factory=dict)
    reasons: dict[str, list[str]] = field(default_factory=dict)
    global_block: list[str] = field(default_factory=list)  # whole recommendation withheld


def evaluate(patient: pd.Series, trials: dict[str, dict[str, float]]) -> GateResult:
    res = GateResult()
    # --- global stops: no personalised advice, escalate to clinician ---
    if patient.get("ga_weeks", 40) < 37:
        res.global_block.append("Gestational age <37 weeks: outside validated population.")
    if patient.get("hypertensive", 0) and patient.get("bmi", 0) > 45:
        res.global_block.append("Severe risk-profile combination: clinician-led decision only.")
    for pose in POSE_PROFILES:
        reasons: list[str] = []
        t = trials.get(pose)
        pr = POSE_PROFILES[pose]
        if t is None:
            reasons.append("Not trialled: no sensor data for this pose.")
        else:
            if t["fhr_decel_count"] >= 3:
                reasons.append(f"≥3 FHR decelerations during trial ({t['fhr_decel_count']:.0f}).")
            if t["fhr_baseline_delta_bpm"] <= -20:
                reasons.append(f"FHR baseline fell {abs(t['fhr_baseline_delta_bpm']):.0f} bpm in this pose.")
            if t["maternal_spo2_nadir"] < 92:
                reasons.append(f"Maternal SpO2 nadir {t['maternal_spo2_nadir']:.0f}% < 92%.")
            if t["comfort_vas"] <= 1.5:
                reasons.append("Mother rated the pose intolerable.")
        if patient.get("knee_limitation", 0) and pr.mobility_demand >= 0.8:
            reasons.append("Knee limitation: deep flexion not advised.")
        if patient.get("epidural", 0) and pr.epidural_penalty >= 0.5:
            reasons.append("Epidural in situ: pose unsafe without assisted support.")
        res.allowed[pose] = not reasons
        res.reasons[pose] = reasons
    return res
