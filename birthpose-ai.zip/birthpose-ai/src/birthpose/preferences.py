"""Mother's own priorities -> utility weights.

The mother rates how much each goal matters to her (1 = not important,
5 = very important). The ratings re-weight the SAME trained model at the point
of care; no retraining is needed.

Safety floor: fetal safety can never be weighted below FETAL_SAFETY_FLOOR,
whatever the mother answers. Her preferences steer between safe options; they
cannot switch safety off. (The rule-based safety gate is separate and unaffected.)
"""
from __future__ import annotations

from .config import UtilityWeights

QUESTIONS = {
    "short_pushing": "A shorter pushing stage",
    "baby_safety": "Keeping my baby's heart rate stable",
    "avoid_tears": "Lowering my chance of perineal tears",
    "comfort": "Being as comfortable as possible",
}
FETAL_SAFETY_FLOOR = 0.25


def weights_from_priorities(ratings: dict[str, int]) -> UtilityWeights:
    """Convert 1-5 ratings to normalised weights with the safety floor applied."""
    unknown = set(ratings) - set(QUESTIONS)
    if unknown:
        raise ValueError(f"unknown priority keys: {sorted(unknown)}")
    r = {k: float(ratings.get(k, 3)) for k in QUESTIONS}  # unanswered = neutral
    if any(v < 1 or v > 5 for v in r.values()):
        raise ValueError("ratings must be between 1 and 5")
    total = sum(r.values())
    w = {k: v / total for k, v in r.items()}
    if w["baby_safety"] < FETAL_SAFETY_FLOOR:
        others = 1.0 - w["baby_safety"]
        scale = (1.0 - FETAL_SAFETY_FLOOR) / others
        w = {k: (FETAL_SAFETY_FLOOR if k == "baby_safety" else v * scale) for k, v in w.items()}
    return UtilityWeights(duration=w["short_pushing"], fetal_safety=w["baby_safety"],
                          perineal=w["avoid_tears"], comfort=w["comfort"])
