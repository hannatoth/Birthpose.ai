import pytest

pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

from birthpose.api import app as app_module  # noqa: E402
from birthpose.config import RankerConfig, SimConfig  # noqa: E402
from birthpose.models.ranker import PoseRanker  # noqa: E402
from birthpose.simulation.generator import simulate  # noqa: E402


def test_recommend_endpoint(monkeypatch):
    patients, long, obs = simulate(SimConfig(n_patients=1500, seed=2))
    app_module._ranker = PoseRanker(RankerConfig(n_ensemble=2)).fit(patients, long, obs)
    client = TestClient(app_module.app)
    pid = 3
    base = patients[patients.patient_id == pid].drop(columns=["patient_id"]).iloc[0].to_dict()
    base["parity"] = int(base["parity"])
    trials = long[long.patient_id == pid]
    cols = ["peak_iap_mmhg", "pelvic_floor_descent_mm", "maternal_hr_delta_bpm", "maternal_spo2_nadir",
            "fhr_baseline_delta_bpm", "fhr_decel_count", "posture_sway_rms_mm", "hold_duration_s", "comfort_vas"]
    body = {"baseline": base, "trials": [{"pose": r.pose, **{c: float(getattr(r, c)) for c in cols}}
                                         for r in trials.itertuples()]}
    r = client.post("/v1/recommend", json=body)
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["status"] in ("ok", "abstain", "withheld")
    assert "disclaimer" in j
    assert client.get("/healthz").json()["status"] == "ok"
    q = client.get("/v1/priorities/questions").json()
    assert set(q["questions"]) == {"short_pushing", "baby_safety", "avoid_tears", "comfort"}
    r2 = client.post("/v1/recommend", json={**body, "priorities": {"comfort": 5, "short_pushing": 1}})
    assert r2.status_code == 200, r2.text
    assert r2.json()["priorities_used"] == {"comfort": 5, "short_pushing": 1}
    assert client.post("/v1/recommend", json={**body, "priorities": {"comfort": 9}}).status_code == 422
    body["trials"] = body["trials"][:2]
    assert client.post("/v1/recommend", json=body).status_code == 422
