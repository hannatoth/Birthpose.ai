import numpy as np
import pandas as pd
import pytest

from birthpose.config import POSES, RankerConfig, SimConfig
from birthpose.models.ranker import PoseRanker, build_features
from birthpose.safety.gate import evaluate
from birthpose.signals.fhr import fhr_features
from birthpose.simulation.generator import simulate


@pytest.fixture(scope="module")
def sim():
    return simulate(SimConfig(n_patients=3000, trial_fidelity=0.7, seed=1))


def test_simulation_shapes(sim):
    patients, long, obs = sim
    assert len(patients) == 3000
    assert len(long) == 3000 * len(POSES)
    assert len(obs) == 3000
    assert obs.patient_id.is_unique
    assert set(obs.pose) <= set(POSES)


def test_supine_has_more_fhr_risk_than_left_lateral(sim):
    _, long, _ = sim
    m = long.groupby("pose").fhr_p_true.mean()
    assert m["lithotomy_supine"] > m["left_lateral"]


def test_fidelity_controls_signal_informativeness():
    corrs = []
    for f in (0.0, 0.9):
        _, long, _ = simulate(SimConfig(n_patients=2000, trial_fidelity=f, seed=3))
        sq = long[long.pose == "supported_squat"]
        corrs.append(abs(np.corrcoef(sq.pelvic_floor_descent_mm, sq.utility_true)[0, 1]))
    assert corrs[1] > corrs[0] + 0.1


def test_ranker_runs_and_gate_is_respected(sim):
    patients, long, obs = sim
    r = PoseRanker(RankerConfig(n_ensemble=2), seed=0).fit(patients, long, obs)
    pid = 5
    feats = build_features(patients[patients.patient_id == pid], long[long.patient_id == pid])
    preds = r.predict(feats)
    allowed = {z: z != "supported_squat" for z in POSES}
    rec = r.recommend(preds, allowed)
    assert len(rec["top"]) == 3
    assert all(t["pose"] != "supported_squat" for t in rec["top"])


def test_gate_blocks_fetal_distress_and_epidural():
    pat = pd.Series(dict(ga_weeks=39, hypertensive=0, bmi=25, knee_limitation=0, epidural=1))
    ok = dict(peak_iap_mmhg=50, pelvic_floor_descent_mm=9, maternal_hr_delta_bpm=15, maternal_spo2_nadir=97,
              fhr_baseline_delta_bpm=0, fhr_decel_count=0, posture_sway_rms_mm=5, hold_duration_s=30, comfort_vas=6)
    bad = {**ok, "fhr_decel_count": 4}
    res = evaluate(pat, {"left_lateral": ok, "hands_and_knees": bad, "supported_squat": ok})
    assert res.allowed["left_lateral"]
    assert not res.allowed["hands_and_knees"]
    assert not res.allowed["supported_squat"]  # epidural
    assert not res.allowed["semi_recumbent"]  # not trialled


def test_gate_global_block_preterm():
    pat = pd.Series(dict(ga_weeks=34))
    assert evaluate(pat, {}).global_block


def test_fhr_features_detect_decel():
    fs = 4
    t = np.arange(0, 600 * fs) / fs
    x = 140 + 3 * np.sin(t / 5)
    x[800:1000] -= 30  # 50 s deceleration
    f = fhr_features(x, fs)
    assert 135 < f["baseline"] < 145
    assert f["n_decels"] >= 1
    assert f["valid_fraction"] > 0.99


def test_priorities_to_weights_and_safety_floor():
    from birthpose.preferences import FETAL_SAFETY_FLOOR, weights_from_priorities
    w = weights_from_priorities({"short_pushing": 5, "baby_safety": 1, "avoid_tears": 5, "comfort": 5})
    assert abs(w.duration + w.fetal_safety + w.perineal + w.comfort - 1) < 1e-9
    assert w.fetal_safety >= FETAL_SAFETY_FLOOR - 1e-9
    assert weights_from_priorities({}).duration == pytest.approx(0.25)
    with pytest.raises(ValueError):
        weights_from_priorities({"comfort": 9})
    with pytest.raises(ValueError):
        weights_from_priorities({"nonsense": 3})


def test_priorities_change_recommendation(sim):
    from birthpose.preferences import weights_from_priorities
    patients, long, obs = sim
    r = PoseRanker(RankerConfig(n_ensemble=2), seed=0).fit(patients, long, obs)
    ids = patients.patient_id.values[:150]
    feats = build_features(patients[patients.patient_id.isin(ids)], long[long.patient_id.isin(ids)])
    comfort_w = weights_from_priorities({"short_pushing": 1, "baby_safety": 1, "avoid_tears": 1, "comfort": 5})
    speed_w = weights_from_priorities({"short_pushing": 5, "baby_safety": 1, "avoid_tears": 1, "comfort": 1})
    def top(w):
        pr = r.predict(feats, w).sort_values("score", ascending=False)
        return pr.groupby("patient_id").head(1).set_index("patient_id").pose.sort_index()
    assert (top(comfort_w) != top(speed_w)).mean() > 0.05
