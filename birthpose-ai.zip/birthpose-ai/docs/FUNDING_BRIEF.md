# Roadmap and funding brief

## One-paragraph pitch
Many women are still steered to give birth on their backs although the best
position differs from woman to woman, and the evidence for any single "best"
position is modest. BirthPose AI is a safety-first decision-support system that
uses a short, sensor-instrumented practice session to shortlist the three
positions most likely to suit a particular mother and baby, with explicit
uncertainty and a rule-based safety gate. We will first test whether the idea is
even possible (Phase 1 go/no-go), then validate prospectively, then run a trial
on operative birth, perineal trauma and birth experience.

## Rationale
Evidence at a glance: [EVIDENCE_AGGREGATE.md](EVIDENCE_AGGREGATE.md).
See [RATIONALE.md](RATIONALE.md) for the problem, evidence, technology readiness, prior work
and the gap, and the Hungarian data opportunity.

## Why personalisation (evidence summary)
Position effects differ by woman (upright helps without epidural; lateral did better
with epidural in a 3,093-woman RCT), anatomy varies and responds to position, and
choice improves satisfaction. The unproven step, sensor-based selection, is tested in
Phase 1. See [EVIDENCE.md](EVIDENCE.md).

## Why Hungary is the right place
Record caesarean rates (42.55% of state-funded births in 2025), frequent episiotomy
and little choice of position, combined with national health-insurance (NEAK/TB)
data that can supply baselines, outcome linkage and cost estimates at national scale.
Position itself is not recorded anywhere, so the project creates the missing data.
Full evidence and limits in [HUNGARY.md](HUNGARY.md).

## Why it is fundable
* **Large, concrete problem:** operative birth, prolonged second stage and negative
  birth experiences carry high clinical, personal and financial costs.
* **De-risked by design:** the biggest unknown (transfer from clinic to labour) is
  tested cheaply in Phase 1 before large spend.
* **Responsible AI built in:** safety gate, abstention, subgroup audit, human
  oversight, pre-registration and publication of negative results.
* **Open assets:** protocol, code, simulator and evaluation harness are open.
* **Clinical support:** concept discussed and approved by a clinician (add name,
  institution and letter of support here).

## Milestones and deliverables

| Phase | Duration | Deliverable | Go/no-go |
|---|---|---|---|
| 0 Preparation | 3–4 mo | Ethics approval, advisory board, preference weights, sensor protocol | Approvals granted |
| 1 Feasibility/transfer | 9–12 mo | n≈150, transfer estimate, acceptability, safety | Lower CI of rank-agreement above threshold |
| 2 Blinded validation | 12–18 mo | n≈600, multi-site, calibration and subgroup report | Pre-set performance and fairness criteria met |
| 3 Pragmatic RCT | 24–36 mo | Primary: operative birth/prolonged second stage; safety | Regulatory submission |

## Team to recruit
Obstetrician (PI) · midwife lead · pelvic-floor physiotherapist · biomedical engineer
(sensors) · ML engineer · biostatistician/trialist · regulatory/QA specialist ·
data-protection officer · patient and public involvement lead.

## Budget scaffolding (to be replaced with quotes)
Personnel (largest) · sensor hardware and ultrasound access · clinical-trial
operations and monitoring · regulatory consultancy and notified-body fees ·
secure cloud/compute · participant reimbursement · open-science and dissemination.
Typical funders to explore: national health research institutes, Horizon
Europe/EIC, Wellcome, Gates Foundation (maternal health), NIH/NICHD, maternal-health
innovation challenges, and medtech accelerators. Check each programme's current
calls and eligibility.

## KPIs
Recruitment rate · completion ≥ 85% · adverse events · transfer estimate with CI ·
calibration slope · regret vs usual care · subgroup performance gap · abstention
rate · clinician and mother acceptability scores · time-to-recommendation in clinic.

## Honest risks
1. Transfer from practice to labour may be weak. **Mitigation:** Phase 1 go/no-go.
2. Benefit may be small for low-risk women. **Mitigation:** target subgroups where
   position matters (OP babies, prolonged second stage history, high BMI).
3. Regulatory timeline is long. **Mitigation:** early regulator dialogue; staged claims.
4. Staff and mother adoption. **Mitigation:** co-design and usability studies.
