# Aggregated evidence: position and choice improve labour and the birth experience

One-page summary for funders. Each row is a study I read. Details and limits: EVIDENCE.md.

## A. Evidence table

| # | Study (type, size) | Finding in favour of using/choosing better positions |
|---|---|---|
| 1 | **Overview of 3 Cochrane reviews**, 65 RCTs, 18,697 women ([Eur J Midwifery](https://www.europeanjournalofmidwifery.eu/Evaluating-the-effects-of-maternal-positions-in-childbirth-An-overview-of-Cochrane,142781,0,2.html)) | Without epidural, upright in first stage: labour ≈ **1.36 h shorter** and **caesarean RR 0.71 (0.54–0.94)**; second stage without epidural: **assisted vaginal birth RR 0.75 (0.66–0.86)**, moderate certainty |
| 2 | **Cochrane, first stage**, 25 RCTs, > 5,000 women (Lawrence 2013, summarised by [Evidence Based Birth](https://evidencebasedbirth.com/positions-during-labor-and-their-effects-on-pain-relief/)) | Upright/mobile labour ≈ **1 h 22 min shorter**, fewer epidural requests, fewer caesareans |
| 3 | **Cochrane, first stage, updated**, 21 studies, 3,706 women ([PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10868947/)) | First stage ≈ **1 h shorter**; **17% less epidural use** (RR 0.83); no harm to mother or baby. (Latest update found no overall difference in mode of birth) |
| 4 | **Cochrane, second stage, no epidural**, 30–32 RCTs, ≈ 9,000 women ([Cochrane](https://www.cochrane.org/evidence/CD002006_position-second-stage-labour-women-without-epidural-anaesthesia)) | ≈ 6 min shorter pushing, **fewer assisted births and fewer episiotomies**; 3 of 4 trials measuring pain found **less pain** upright |
| 5 | **Turkish RCT**, 102 first-time mothers (via [Evidence Based Birth](https://evidencebasedbirth.com/positions-during-labor-and-their-effects-on-pain-relief/)) | Standing/squatting vs lying on back: second stage **≈ 34 min shorter**, **less pain, more satisfaction** |
| 6 | **Swedish Birth Seat RCT** (same source) | Women using a birth seat reported **greater satisfaction** and felt more powerful, protected and self-confident |
| 7 | **Rome cohort**, 2,240 first-time mothers, own choice of position ([PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9941360/)) | Non-supine vs semi-recumbent: **assisted vaginal birth 0% vs 14.6%**, **episiotomy 7.0% vs 56.6%**, perineal trauma OR 0.41 (0.30–0.57), less blood loss (260 vs 314 mL) |
| 8 | **German survey**, 761 women ([PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11919968/)) | Self-chosen position: satisfaction **5.67 vs 4.72 / 7**; staff-dictated position was what lowered satisfaction |
| 9 | **BUMPES RCT**, 3,093 first-time mothers with epidural ([PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC5646262)) | **The best position changes with the woman:** lying on the side beat upright (41.1% vs 35.2% spontaneous vaginal birth) |
| 10 | **MRI**, 50 pregnant women ([AJOG 2014](https://www.em-consulte.com/article/940833/does-pregnancy-andor-shifting-positions-create-mor)) | Kneeling squat widens the pelvis by **0.9–1.9 cm (7–15%)** vs lying on the back |
| 11 | **RCT, back-to-back babies**, 439 women ([summary](https://www.2minutemedicine.com/hands-and-knees-position-ineffective-for-fetal-rotation-improves-comfort)) | Hands-and-knees: **more women improved comfort (34% vs 19%)** |

## B. The logical argument

1. **Position changes real outcomes.** Across 65 trials, positions and mobility shorten
   labour, cut assisted births and episiotomy, reduce epidural use and pain, and in several
   analyses reduce caesareans (rows 1–5, 7).
2. **The benefit depends on the woman.** Upright helps without an epidural; with one,
   lying on the side did better (rows 1, 9). Pelvic space and baby position differ
   (rows 10, 11). One default for everyone cannot capture the benefit.
3. **Choice and fit improve the experience.** Women who choose or are given suitable
   positions are more satisfied and feel more in control (rows 5, 6, 8).
4. **Therefore** a system that identifies the positions that suit a given woman and
   offers her a shortlist to choose from is a logical way to collect these benefits for
   more women: shorter labour, fewer instrumental births and a better experience, with a
   possible reduction in emergency caesareans.
5. **Where Hungary fits:** very high caesarean (42.55%) and episiotomy (> 50%) rates, little
   position choice (23.6% in public care), and national insurance data to measure the
   result (HUNGARY.md).

## C. Primary endpoint implied by the evidence
Composite of **operative birth (instrumental or caesarean) and prolonged second stage**,
with caesarean, perineal trauma, blood loss and birth-experience score as key secondary
outcomes. This is where the pooled evidence is strongest (assisted birth RR 0.75;
caesarean effects appear mainly with upright first-stage labour without epidural).

## D. About the specific American hospital / Instagram example
Upright, mobile and freely chosen positions are an established practice in many US
hospitals and midwifery services, which is consistent with rows 1–8. I could not find or
verify the specific Brooklyn hospital or Instagram account you remember, so it is not
cited here; if you send the link I'll add it as an example of the practice.
