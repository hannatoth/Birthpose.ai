# Data

## Honest summary
**No public dataset links maternal position to labour outcomes together with
sensor signals.** That is exactly why a prospective collection (Phase 1/2) is the
core of the project and why this repo ships a simulator for engineering work.

## What exists publicly (verified in this build)

### CTU-UHB Intrapartum Cardiotocography Database (PhysioNet)
* 552 recordings selected from 9,164 collected at University Hospital Brno
  (2010–2012); each up to 90 minutes with a fetal heart rate series, a uterine
  contraction signal and maternal, delivery and fetal clinical details.
* Includes outcomes such as umbilical pH and Apgar scores; expert annotations are
  available separately.
* **Licence:** free for non-commercial use with citation of the original publication.
  Check this before any commercial use of models derived from it.
* DOI: https://doi.org/10.13026/C22013
* **Use here:** validate the FHR feature extractor on real signals; pre-train a fetal
  stress encoder. **Cannot** train pose recommendations (no position labels).

### Other physiological signal resources to evaluate (not verified in this build)
Search PhysioNet and similar archives for uterine EHG and perinatal datasets and read
each licence and consent scope before use. Treat these as candidates, not confirmed.

## Dataset the project must create

| Table | Key fields |
|---|---|
| `participants` | de-identified id, age, BMI, height, parity, GA, EFW, fetal position, pelvimetry, mobility, back pain, knee/hip limits, hypertension, planned analgesia |
| `pose_trials` | participant, pose, timestamps, sensor features, comfort, abort reason |
| `labour` | positions used with timestamps, epidural, augmentation, second-stage minutes, FHR events |
| `outcomes` | mode of birth, perineal trauma grade, PPH, Apgar, cord pH, NICU admission, birth-experience score |

Standards: FHIR/OMOP-friendly schema, FAIR metadata, data dictionary, versioned data
cards. Storage on approved, encrypted infrastructure; **no raw data in this repo.**

## Hungarian national insurance data (NEAK/TB)
Claims and financing data from the national health insurance can supply hospital
baselines, outcome follow-up and costs, but not position, sensors or experience.
Access needs ethics and data-protection approval. See [HUNGARY.md](HUNGARY.md).

## Simulated data in this repo
`simulate()` produces patients, per-pose sensor features and per-pose true outcomes.
All effect sizes are stylised priors in `config.py`. Do not cite them as findings.
