# Architecture

## 1. System view

1. **Acquisition (clinic)** – wearable and bedside sensors during a scripted
   "pose protocol" (≈ 3 min per pose, 8–10 poses, rest between, abort any time).
2. **Signal layer** – per-pose features from raw signals.
3. **Safety gate** – deterministic rules; runs first and independently.
4. **Outcome models** – pose-conditioned ensembles for four outcomes.
5. **Ranker** – risk-averse utility, top-3, abstention, explanations.
6. **Clinician/mother UI** – shows three options with reasons and exclusions;
   preference sliders re-weight the utility *without retraining*.
7. **Feedback loop** – pose used in labour + outcomes logged (Phase 3) for
   monitoring, drift detection and periodic re-validation.

## 2. Sensor stack (proposed)

| Signal | Sensor | Why |
|---|---|---|
| Maternal HR, SpO₂, respiration | Wearable PPG/ECG patch | Maternal strain / hypoxia |
| Fetal heart rate | Doppler or fetal ECG patch | Fetal tolerance of each pose (gate input) |
| Uterine activity | Tocodynamometer / EHG | Context; practice push vs contraction |
| Intra-abdominal pressure proxy | Belt strain sensor | Push effort |
| Pelvic-floor descent | Transperineal ultrasound or pressure mat | Effective outlet / descent proxy |
| Posture / stability | IMUs on pelvis, thigh, trunk | Pose fidelity, sway, hold time |
| Comfort | 0–10 VAS | Mother's own signal; never optional |

Pose protocol compliance is verified from IMU joint angles so that "supported
squat" means the same thing at every site.

## 3. Modelling decisions and why

* **Counterfactual framing.** The question is "what *would* happen under pose A vs
  B?" but only one pose is ever used in labour. We therefore (a) model outcome as a
  function of pose + patient + that pose's trial signals, (b) correct selection
  bias with inverse-propensity weights, and (c) plan a randomised-within-safe-set
  phase to obtain unconfounded data (see protocol).
* **Within-person contrast features.** Trial signals are also expressed relative to
  the mother's own mean across poses, which removes between-person offsets
  (e.g. a mother with generally high heart rate).
* **Four outcome heads, one utility.** Duration, fetal-heart-rate event, perineal
  trauma and comfort are predicted separately so that preference weights can change
  at the point of care and each head can be audited and calibrated.
* **Ensemble uncertainty + risk-averse score.** `score = mean − κ·std`. A pose the
  model is unsure about is ranked lower.
* **Abstention.** If the best pose does not beat standard of care by a margin the
  system says so and does not invent a recommendation.
* **Rules before ML.** Fetal-distress signs, desaturation, intolerability,
  contraindications and population limits are enforced by an auditable rule set,
  never by a learned model.

## 4. Roadmap of model upgrades (after Phase 1 data exist)

1. Doubly-robust off-policy value estimation and policy learning (replace plain IPW).
2. Hierarchical Bayesian model with site random effects (multi-centre drift).
3. Conformal prediction intervals on each outcome for calibrated coverage.
4. Self-supervised pre-training of an FHR/maternal-physiology encoder on large
   unlabelled CTG archives (CTU-UHB is the open starting point).
5. Pelvic geometry from MRI/ultrasound-derived shape models as an additional input.
6. Federated training across hospitals so raw data never leave sites.
7. Counterfactual fairness audit across BMI, age, ethnicity, disability.

## 5. Software engineering

* Python 3.10+, typed, tested (pytest), CI on GitHub Actions.
* Gate and model are separate packages so the gate can be certified on its own
  (IEC 62304 software safety class to be determined by risk analysis).
* Model artefacts are versioned and hashed; every recommendation logs model
  version, gate version, inputs and outputs for audit.
