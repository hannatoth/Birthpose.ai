# Evidence that personalising birthing position is worthwhile

**Short version.** No single position is best for everyone, the effect of position
changes sign depending on the woman, mothers are more satisfied when position fits
and is chosen by them, and bodies differ measurably. Together this is a strong case
that *a good position for her* beats *one default for all*. What is **not** yet
shown by anyone is that a **sensor-based practice session** can pick her best
positions. That is the hypothesis this project tests (see STUDY_PROTOCOL.md).

## 1. The best position differs by woman (effect heterogeneity)

| Finding | Evidence |
|---|---|
| Without epidural, upright positions give a small benefit: ≈ 6 min shorter pushing, fewer assisted births and episiotomies, but more blood loss ≥ 500 mL and a tendency to more tears (low-quality evidence) | [Cochrane review, Gupta et al. 2017](https://www.cochrane.org/evidence/CD002006_position-second-stage-labour-women-without-epidural-anaesthesia) |
| **With a low-dose epidural, first-time mothers did better lying on their side**: spontaneous vaginal birth 41.1% lying down vs 35.2% upright (adjusted RR 0.86 for upright, 95% CI 0.78–0.94; NNT 17; 3,093 women, 41 UK units) | [BUMPES RCT](https://pmc.ncbi.nlm.nih.gov/articles/PMC5646262) |

The same advice ("go upright") helps one group and hurts another. A rule for
everybody therefore cannot be optimal, and the **epidural flag is already a core input
and gate rule in this repo**. That is the strongest published argument for
subgroup-specific, and ultimately individual, recommendations.

## 2. Women differ anatomically and by baby position

* **MRI pelvimetry (50 pregnant women, 2014):** moving from lying on the back to a
  kneeling squat widened the bispinous diameter from 12.6 to 14.5 cm and the
  bituberous diameter from 13.6 to 14.5 cm (all p < 0.0001); the authors report
  gains of 0.9–1.9 cm (7–15%) in transverse pelvic diameters
  ([Reitter et al., AJOG 2014](https://www.em-consulte.com/article/940833/does-pregnancy-andor-shifting-positions-create-mor)).
  The spread between women (SD ≈ 0.65–0.9 cm) is comparable to the change position
  produces, which is the biomechanical room personalisation can use. Only two
  positions were compared.
* **Persistent occiput-posterior (back-to-back) babies, 439 women:** hands-and-knees
  did not significantly increase rotation (17% vs 12%, RR 1.5, 95% CI 0.9–2.4) but
  more women reported improved comfort (34% vs 19%, p = 0.02)
  ([trial summary](https://www.2minutemedicine.com/hands-and-knees-position-ineffective-for-fetal-rotation-improves-comfort)).
  Benefits depend on the individual situation and on what outcome you value.

## 3. Fit and choice drive the birth experience

In a survey of 761 women with unassisted vaginal births in Germany, 77.5% gave birth
on their back or side, 31% did not choose their position freely (staff instruction was
the main reason), and mean satisfaction (7-point scale) was **5.67 when self-chosen vs
4.72 when externally determined** (p < 0.01); in the adjusted model, staff-dictated
position was the factor linked to lower satisfaction, while position type alone was
not significant
([Scholten, Strizek et al. 2024](https://pmc.ncbi.nlm.nih.gov/articles/PMC11919968/)).
Caveats: cross-sectional, 27.6% response rate, self-reported.

This supports giving women a **shortlist they can choose from** (our top-3 design)
rather than assigning a single "best" pose.

## 4. What this means for the project

| Claim | Status |
|---|---|
| No single best position; the benefit depends on epidural status and individual factors | **Supported** (Cochrane vs BUMPES) |
| Anatomy responds differently to position and varies between women | **Supported** (MRI), small sample |
| Choice and fit improve satisfaction | **Supported**, observational (one large German survey; no randomised trial found) |
| A pre-labour sensor session can rank a woman's best positions | **Unproven; this is the project's hypothesis** |
| Personalised top-3 improves operative birth rate or birth experience | **Unproven; Phase 3 trial** |

## 5. Gaps and honest limitations
* Most position trials randomise *position vs position for everyone*; few estimate
  **individual** treatment effects, so published heterogeneity is mainly by epidural
  status and parity.
* Evidence quality is low-to-moderate; outcomes and definitions differ across trials.
* Position changes during labour; the last position before birth is not the whole story.
* Benefit for experience may come from choice and respect as much as geometry;
  the trial should separate "personalised" from "simply offered a choice".

## 6. Design implications already in the code
* Epidural is a model input and a safety-gate rule (`safety/gate.py`).
* Lateral positions remain candidates for epidural users (BUMPES arm).
* Top-3 shortlist plus the mother's own priorities (`preferences.py`) puts her in control.
* Phase 3 compares personalised guidance vs usual care **and** vs choice-only to test
  whether sensors add value beyond choice.

## 7. Can choosing or personalising position avoid emergency caesareans?

**Honest answer: plausible, not shown.** Be careful how this is worded in the application.

| Evidence | Finding |
|---|---|
| Cochrane (30 trials, 9,015 women, no epidural) | Fewer assisted (instrumental) births in upright positions (21 trials), **no difference in caesarean rate** (16 trials, 5,439 women) ([Cochrane 2017](https://www.cochrane.org/evidence/CD002006_position-second-stage-labour-women-without-epidural-anaesthesia); counts from a [summary](https://www.mdedge9-ma1.mdedge.com/node/139499/path_term/49726)) |
| BUMPES (epidural, 3,093 first-time mothers) | Caesarean and instrumental birth not significantly different between arms ([BUMPES](https://pmc.ncbi.nlm.nih.gov/articles/PMC5646262)) |
| Rome single-centre cohort, 2,240 first-time mothers, women chose their own position | Free non-supine position (23.1% of women) vs semi-recumbent: assisted vaginal birth 0% vs 14.6%, episiotomy 7.0% vs 56.6%, any perineal trauma OR 0.41 (95% CI 0.30–0.57). **Caesarean not reported.** Retrospective and self-selected, so confounded ([Gemelli cohort](https://pmc.ncbi.nlm.nih.gov/articles/PMC9941360/)) |

What supports the idea: better positions plausibly shorten or ease the pushing stage and
reduce instrumental births, and some caesareans follow a failed push or failed
instrumental attempt. What does not: randomised trials so far show no overall caesarean
difference. Since the best position differs by woman (e.g. epidural), pooled averages
could hide real benefit for some women and harm for others, which is precisely the
personalisation hypothesis. That remains a hypothesis.

**Recommended wording:** "Position may reduce operative and instrumental births and
second-stage complications for some women; we will test whether personalised guidance
lowers a composite of operative birth and prolonged second stage, with caesarean as a
monitored secondary outcome."

**Study to add if found:** you recalled an American hospital study on this. I could not
identify it. Please send a title, link or hospital name and it will be added; until
verified it should not be cited.
