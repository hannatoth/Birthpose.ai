# Ethics, safety and regulatory plan

*This is a planning document, not legal advice. Confirm all points with a
regulatory consultant and your notified body/competent authority.*

## Intended use (draft)
Decision support that offers a ranked shortlist of birthing positions to a pregnant
woman and her clinician, based on a pre-labour practice session. It does not
diagnose, monitor labour, or replace clinical judgement or maternal choice.

## Likely regulatory status
* Software that drives or informs a clinical decision about care is likely a medical
  device (EU: software as a medical device under MDR, probably class IIa or higher
  under rule 11; US: FDA clinical decision support / SaMD pathway, likely De Novo or
  510(k)). Classification must be confirmed with the authorities.
* EU AI Act: medical-device AI is generally high-risk → requirements on risk
  management, data governance, transparency, human oversight, logging, accuracy
  and robustness.
* Quality and safety standards to plan for: ISO 13485 (QMS), ISO 14971 (risk),
  IEC 62304 (software lifecycle), IEC 62366 (usability), IEC 60601 for any
  electrical sensors, and good clinical practice (ISO 14155) for investigations.
* Data protection: GDPR (health data, DPIA, lawful basis, minimisation) and
  HIPAA where relevant.

## Principal risks and mitigations

| Hazard | Mitigation |
|---|---|
| Practice session does not transfer to labour → useless or misleading advice | Phase 1 go/no-go on measured transfer; abstention; "decision support only" labelling |
| Pose harms the baby (e.g. cord/FHR compromise) | Rule-based gate on FHR/SpO₂/discomfort, independent of ML; clinician in the loop |
| More bleeding or tears in upright poses | PPH and trauma modelled as outcome heads; monitored harms in all trials |
| Automation bias (staff defer to the AI) | Show 3 options with reasons and uncertainty; mother's preference prevails; training |
| Bias against groups under-represented in data | Subgroup reporting, recruitment targets, fairness audit, post-market monitoring |
| Epidural or mobility limits ignored | Gate blocks infeasible poses; models include these covariates |
| Over-claiming to patients or funders | Public statement of limits; simulation results labelled as simulated |
| Data breach | Minimisation, encryption, pseudonymisation, access logs, federated options |

## Participant-centred principles
* Choice and dignity: the aim is *more* options for birthing women, not another
  rule imposed on them. Recommendations are optional and overridable.
* Equity: include women with high BMI, disabilities, and from diverse backgrounds
  from the start; do not validate only on low-risk, low-BMI cohorts.
* Transparency: explain in plain language why a pose was ranked or excluded.
* Benefit sharing: publish negative results; make the protocol and (de-identified,
  licence-permitting) code open.
