# Why Hungary: the problem and the data opportunity

## 1. The problem in Hungarian numbers

| Indicator | Figure | Source |
|---|---|---|
| Caesarean rate, state-funded births, 2025 | **42.55%** (28,385 of 66,714), a record; 41.6% in 2024; 38.45% in 2015 | NEAK figures reported by [Economx, 10 Jul 2026](https://www.economx.hu/belfold/2026/07/10/csaszarmetszes-tortenelmi-rekord-szules-korhaz-neak-egeszsegugy/) |
| Reference points | WHO population-level range ≈ 10–15%; most OECD countries ≈ 25–35% | same article |
| Caesarean, children born 2018/19 | 43% (24% planned, 19% unplanned) | [Kohorsz '18 (KSH NKI)](https://www.kohorsz18.hu/eredmenyek/elozetes-eredmenyek/106-a-szules-lezajlasa.html) |
| Vaginal births with episiotomy | More than half (WHO suggests ≈ 10–15%) | Kohorsz '18, same page |
| Birth experience | ≈ 1 in 10 mothers called it bad; 78% of vaginal births positive, but only ≈ 37% of unplanned caesareans | Kohorsz '18, same page |
| Could choose position (vaginal births, public hospital care) | **23.6%** (vs 86.7% in community birth) | [Rubashkin et al., *Birth* 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC11345881/) (2014 survey, N=1,257) |
| Episiotomy, public option | 62.3% of vaginal births (4.4% in community birth) | same paper |
| Self-reported disrespectful care, public option | 64.3% | same paper |

### What the evidence does and does not show about lying on the back

* **Not shown:** I found **no Hungarian dataset that records how many women give
  birth on their back, or that links birth position to outcomes.** Hungarian
  statistics do not measure position. So the statement "back-lying is a major cause of
  poor outcomes in Hungary" **cannot be supported with Hungarian data today**, and
  the project should not claim it.
* **What can be said:** Hungarian public-hospital births combine very high
  intervention rates, low position choice and frequent reports of disrespectful care.
  Back-lying is a plausible contributor, and it is exactly the thing nobody measures.
* **International evidence on position:** a Cochrane review of upright vs supine
  second-stage positions (women without epidural) found a small reduction in pushing
  time (≈ 6 min), fewer assisted deliveries and fewer episiotomies, but also more
  blood loss ≥ 500 mL and a tendency to more tears, with low-quality evidence
  ([Gupta et al., 2017](https://www.cochrane.org/evidence/CD002006_position-second-stage-labour-women-without-epidural-anaesthesia)).
* **Experience evidence (Germany, not Hungary):** in a 2024 questionnaire study of
  ≈ 800 mothers, over three quarters gave birth on their side or back, up to 40% of
  those said they did not choose it, and satisfaction was higher when mothers chose
  their own position ([Scholten, Strizek et al., 2024, Arch Gynecol Obstet](https://www.uni-bonn.de/en/news/lying-sitting-or-all-fours-position)).

**Project framing:** "Hungary has high intervention rates and little choice in birth
position, but no one measures position, so we do not know how much it matters or
for whom. BirthPose AI both measures it and personalises it."

Caveats on the sources: the Rubashkin data are a 2014 survey with a convenience
component; Kohorsz '18 reports at six months after birth; NEAK figures cover state-
funded births only (about 1 in 8 babies is born in a private unit per Economx).

## 2. The data opportunity: Hungary's national health insurance (TB / NEAK)

Hungary finances most care through its national social health insurance, administered
by the National Health Insurance Fund Administration (NEAK, formerly OEP). NEAK's
financing database has already been used for published national analyses over
many years, for example a 2002–2018 analysis of laboratory spending
([Boncz et al., Orvosi Hetilap 2020](https://real.mtak.hu/108099/)).
*(Note: the NEAK English page I checked describes its central financing role but does
not itself use the words "single insurer". Confirm the exact wording and a citable source,
e.g. an OECD/European Observatory country profile, before submitting.)*

### What it could give this project
1. **Realistic baselines per hospital:** caesarean, instrumental birth, episiotomy,
   perineal injury, length of stay, neonatal admission. These feed the sample-size
   calculation, a cluster or stepped-wedge trial and site selection.
2. **Outcome linkage:** follow mother and baby after discharge (readmission,
   postpartum complications) through one national record rather than hospital by hospital.
3. **Natural variation:** very large differences between hospitals in intervention
   rates allow a first look at which practices travel with better outcomes.
4. **Health-economics:** national case costs turn avoided emergency caesareans and
   complications into a credible cost-effectiveness case for funders and the payer.
5. **Equity audit:** a population-wide denominator to check performance by region,
   age and socio-economic group; Hungarian work on discrimination in childbirth
   care (for example [this study on Roma women](https://www.sciencedirect.com/science/article/abs/pii/S1877575624000685))
   should be reviewed when designing the audit.
6. **Scalability:** a single payer can reimburse an effective tool nationally.

### What it cannot give (be honest with funders)
* Insurance data are **claims/financing data**: procedures, diagnoses, costs. They do
  **not** contain birth position, sensor signals, fetal heart traces, cord pH, or how
  the mother experienced the birth. Those must be collected prospectively (Phase 1–2).
* Private-clinic births are not fully captured.
* **Access is not automatic.** Health data are special-category data under GDPR and
  Hungarian health-data law; use needs ethics approval (in Hungary via the medical
  research ethics system), a data-protection impact assessment, a legal basis, and an
  approved data request. Plan months for this and involve a data-protection officer
  early. Confirm the exact procedure with NEAK and the relevant authorities.
* Accuracy of coding (e.g. episiotomy and perineal tear codes) must be audited
  before it is used as an outcome.

### Recommended data strategy
`Prospective sensor/position study (new, small, rich)` + `NEAK-linked outcomes and
baselines (large, shallow)` = a design nobody else can easily replicate.
Hospital-held pseudonymised study IDs link the two; no raw identifiers leave hospitals.

## 3. Hungarian pilot suggestions
* Start with 1–2 university obstetric departments and a midwife-led or birth-centre
  partner so both usual care and position-friendly care are represented.
* Co-design with Hungarian mothers' organisations, midwives and the clinical advisor.
* Funding to explore (check current calls): NKFIH (national research office), EU
  Horizon Europe, EIT Health, plus maternal-health innovation programmes.
