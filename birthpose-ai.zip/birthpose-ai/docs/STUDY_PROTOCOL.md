# Study protocol (draft for clinical-partner review)

**Principle:** each phase has a pre-specified *go/no-go* criterion. If the central
hypothesis fails, we stop and publish the negative result. This is what makes the
project fundable and ethical.

## Central hypothesis and the key risk

A short clinic-time practice push (non-labouring, usually 36–39 weeks) carries
information about which position will work best in actual second-stage labour.

**This is unproven and may be false.** Labour physiology differs (uterine
contractions, hormones, fetal descent, fatigue, pain, epidural). Our simulator
parameter `trial_fidelity` stands for this. Phase 1 estimates it.

## Phase 0 – Preparation (3–4 months)
* Clinical advisory board (obstetrician, midwives, physiotherapist, patient
  representatives, biomedical engineer, ethicist, statistician).
* Core Outcome Set for childbirth research for outcome definitions.
* **Preference elicitation:** discrete-choice survey of mothers and clinicians to set
  utility weights (duration vs fetal safety vs trauma vs comfort).
* Ethics approval, data-protection impact assessment, device safety file for
  *investigational* sensor use (non-significant risk where applicable).

## Phase 1 – Feasibility and transfer study (≈ 150 women, single/dual centre)
* Low-risk singleton pregnancies, 36+0–39+6 weeks, consenting, no contraindication
  to the poses. Abort rules: any fetal-heart-rate concern, maternal discomfort,
  contractions, bleeding.
* Each participant completes the pose protocol; all signals logged.
* **Outcome:** the position(s) actually used in second stage, second-stage duration,
  FHR events, perineal outcome, comfort; labour managed entirely per standard care
  (no recommendation shown to anyone).
* **Primary analysis:** does within-person ranking of poses from trial signals predict
  within-person comfort and mechanical efficiency in labour among the poses that
  were actually used? Report estimated transfer ("fidelity") with a CI.
* **Go/no-go:** proceed only if the lower CI bound of rank-agreement (e.g. Kendall τ
  or top-3 agreement vs chance) is above a pre-set threshold *and* the protocol is
  safe and acceptable (completion ≥ 85%, no serious adverse events attributable).

## Phase 2 – Prospective, blinded model validation (≈ 600 women, 3–4 centres)
* Model recommendations are generated but **not shown**; care as usual.
* Pre-registered primary endpoint: regret/agreement between model-ranked poses and
  poses actually used and outcome achieved, using doubly-robust off-policy
  evaluation; secondary: calibration, subgroup performance, abstention rate.
* Optional **randomised-within-safe-set** sub-study where staff offer, with consent,
  one of the top-3 vs usual care poses to break confounding.

## Phase 3 – Pragmatic randomised trial (sample size from Phase 1–2 variance)
* Mothers randomised to (a) personalised top-3 guidance or (b) usual care/choice.
* Primary: composite of operative birth (instrumental or caesarean) and
  prolonged second stage. Key safety: neonatal outcomes, severe perineal trauma,
  postpartum haemorrhage (the Cochrane review flags more ≥500 mL blood loss in
  upright poses, so this is a monitored harm, not an afterthought).
* Secondary: birth experience (validated scale), comfort, health-economic outcomes.
* Stepped-wedge design is an option for hospital-level implementation.

## Statistical safeguards
* Pre-registered analysis plans; hold-out sites for external validation.
* Subgroup performance reported for parity, BMI, age, ethnicity, epidural use,
  fetal position, disability. Subgroup regret is already computed in the codebase
  (`subgroup_table`).
* Data-monitoring committee with stopping rules for harm.

## Consent and participant experience
* Plain-language consent; participation never changes the care a woman receives.
* Recommendations are optional, explainable and overridable by the mother.
* Option to withdraw and have data deleted at any time before analysis.
