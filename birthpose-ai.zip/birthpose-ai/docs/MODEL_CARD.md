# Model card — BirthPose ranker v0.1 (simulation-only)

**Status:** research prototype trained on synthetic data. Not for clinical use.

**Intended use:** engineering and study-design experiments (power analysis, stress
tests, UI development). **Out of scope:** any advice to real patients.

**Inputs:** 14 baseline covariates (age, BMI, height, parity, gestational age,
estimated fetal weight, occiput-posterior flag, station, epidural, hip mobility,
back pain, knee limitation, hypertension, pelvimetry z-score) plus 9 per-pose
sensor features and their within-person relative versions.

**Outputs:** per pose: expected utility, uncertainty, predicted second-stage
minutes, FHR-event risk, perineal-trauma risk, comfort. Top-3 allowed poses or
abstain.

**Training:** four gradient-boosted outcome heads × 5-member bootstrap ensemble, with
inverse-propensity weights (propensity from a multinomial logistic model).

**Evaluation (simulated, 1,500 held-out women, trial fidelity 0.6):**
top-3 regret 0.010 vs 0.079 for "everyone semi-recumbent"; true best pose inside
the top-3 for 51%; abstains for 3.6%. See README for the full comparison and
fidelity sweep.

**Known limitations**
* Ground truth is generated from my assumed physiology; results prove the pipeline,
  not clinical benefit.
* "Practice push → labour" transfer is assumed via a single parameter.
* Utility weights are placeholders pending preference elicitation.
* Ten pose categories are coarse; real poses vary continuously.
* No ethnicity, pelvic-shape imaging or labour-augmentation variables yet.
* Subgroup results are simulated; real fairness testing is required.

**Ethical considerations:** see ETHICS_REGULATORY.md.
