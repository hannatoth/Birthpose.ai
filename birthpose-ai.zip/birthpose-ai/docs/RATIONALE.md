# Rationale: why build this, why now, why Hungary

## 1. The problem
* **Too many interventions, too little choice.** Hungary's state-funded caesarean rate
  hit a record 42.55% in 2025 ([Economx/NEAK](https://www.economx.hu/belfold/2026/07/10/csaszarmetszes-tortenelmi-rekord-szules-korhaz-neak-egeszsegugy/));
  more than half of vaginal births involve an episiotomy and about 1 in 10 mothers call
  the birth a bad experience ([Kohorsz '18](https://www.kohorsz18.hu/eredmenyek/elozetes-eredmenyek/106-a-szules-lezajlasa.html));
  only 23.6% of women in public care could choose their position in a 2014 survey
  ([Rubashkin 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC11345881/)). See HUNGARY.md.
* **Birth position is a plausible, cheap, safe lever that nobody measures.** In
  Hungary it is not recorded at all; in Germany staff dictated the position for about a
  third of women and satisfaction was lower when they did
  ([Scholten 2024](https://pmc.ncbi.nlm.nih.gov/articles/PMC11919968/)).

* **Why it might avoid operative births:** a Rome cohort of 2,240 first-time mothers found
  0% assisted vaginal births with freely chosen non-supine positions vs 14.6% semi-recumbent
  (observational, caesarean not reported; [Gemelli cohort](https://pmc.ncbi.nlm.nih.gov/articles/PMC9941360/)),
  while randomised trials show fewer assisted births but **no overall caesarean difference**.
  So "avoids some emergency caesareans" is a hypothesis to test, not a finding (EVIDENCE.md §7).

## 2. The science supports personalising, not one default

One-page study table and argument: EVIDENCE_AGGREGATE.md.

* Upright helps a little without an epidural ([Cochrane 2017](https://www.cochrane.org/evidence/CD002006_position-second-stage-labour-women-without-epidural-anaesthesia)),
  but with an epidural, first-time mothers did better lying on their side
  (41.1% vs 35.2% spontaneous vaginal birth, 3,093 women; [BUMPES](https://pmc.ncbi.nlm.nih.gov/articles/PMC5646262)).
* Position changes pelvic geometry by 7–15% and women differ ([Reitter 2014](https://www.em-consulte.com/article/940833/does-pregnancy-andor-shifting-positions-create-mor)).
* For back-to-back babies, hands-and-knees did not clearly rotate the baby but more
  women felt more comfortable (34% vs 19%; [trial summary](https://www.2minutemedicine.com/hands-and-knees-position-ineffective-for-fetal-rotation-improves-comfort)).
* Full table and limits: EVIDENCE.md.

## 3. The technology is ready
* **ML on labour data works.** A multicentre study of 63,401 vaginal births in China
  predicted second-stage duration with AUC ≈ 0.81–0.86 using eight routine variables
  ([Huang et al., eClinicalMedicine 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC11831126/)),
  but it did not recommend positions.
* **Position biomechanics can be measured.** Motion-capture studies of upright birthing
  positions exist ([UCLan/Topalidou et al.](https://clok.uclan.ac.uk/54804)), and
  wireless wearable sensors for pregnancy and newborn monitoring have been developed
  ([Northwestern](https://news.feinberg.northwestern.edu/?p=102743)).
* **Open fetal-signal data and methods exist** (CTU-UHB, see DATA.md).

## 4. Prior work and the gap

| Area | What exists | What is missing |
|---|---|---|
| Position RCTs and reviews | Many; average effects by position, some subgroup results | Predicting **which position suits which woman** |
| ML in labour | Duration and mode-of-delivery prediction (e.g. Huang 2025) | Recommending a **position**; using a **pre-labour practice session** |
| Sensors in pregnancy and birth | Wearables, motion capture | A validated link from practice-session readings to labour outcomes |
| Position data at national scale | None found for Hungary | Position recorded together with outcomes |

**I did not find a published system that does what BirthPose AI proposes** (sensor-
guided practice session, then personalised top-3 positions). This is a literature search
by one assistant, not a systematic review. **Before submitting, complete a proper search
(PubMed, Embase, IEEE, ClinicalTrials.gov registry) and add any study you or your
clinician know of.** If you have seen a specific study on this, add it to the table
above: if it already shows the approach works, cite it as supporting evidence; if it
overlaps, position BirthPose as validation or extension in a Hungarian setting.

*Found but not yet read in full (review before citing):* a 2025 meta-analysis of
maternal positions and occiput-posterior malposition (AJOG MFM), a 2026 network
meta-analysis of position and perineal trauma, a 2026 prospective observational study
of upright positions and outcomes, and a 2024 RCT of posture and cognitive-behavioural
interventions with abnormal fetal head position.

## 5. Why Hungary is an unusually good place
* **Large, measurable need** (numbers above).
* **A national health insurer (NEAK/TB) holds nationwide claims data** that can supply
  hospital-level baselines, follow-up after discharge and cost estimates, which makes
  sample-size planning, a hospital-level trial and a health-economic case more credible
  than in fragmented systems. It does not hold position or sensor data, so the study
  collects those prospectively and links them. Access needs ethics and data-protection
  approval. See HUNGARY.md.
* **A payer that can scale** an effective, low-cost intervention nationally.
* **Clinical support:** concept reviewed by a clinician (add name and letter).

## 6. The pitch in four sentences
Position is a low-risk lever on birth outcomes that Hungarian data do not even record.
Trials show the best position depends on the woman, for example epidural status, so
one default cannot be optimal. Sensors and ML can now measure and learn individual
differences, and Hungary's national insurance data make evaluation and scaling
unusually feasible. We first test the one unproven step, whether a practice session
predicts the best position, before any large investment.
