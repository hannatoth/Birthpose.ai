"""End-to-end experiment: simulate -> train -> evaluate -> sweep trial fidelity.

    python scripts/run_experiment.py --n 12000 --out results
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from birthpose.config import RankerConfig, SimConfig
from birthpose.evaluation.metrics import evaluate_policy, subgroup_table
from birthpose.models.ranker import PoseRanker
from birthpose.simulation.generator import simulate


def run(n: int, fidelity: float, policy: str, seed: int, n_test: int):
    cfg = SimConfig(n_patients=n, trial_fidelity=fidelity, seed=seed, logging_policy=policy)
    patients, long, obs = simulate(cfg)
    ids = patients.patient_id.values
    rng = np.random.default_rng(seed)
    test_ids = rng.choice(ids, size=min(n_test, n // 4), replace=False)
    train_ids = np.setdiff1d(ids, test_ids)
    ranker = PoseRanker(RankerConfig(), seed=seed).fit(
        patients[patients.patient_id.isin(train_ids)], long[long.patient_id.isin(train_ids)],
        obs[obs.patient_id.isin(train_ids)])
    df, summary = evaluate_policy(ranker, patients, long, test_ids, seed)
    return ranker, df, summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=12000)
    ap.add_argument("--n-test", type=int, default=1500)
    ap.add_argument("--fidelity", type=float, default=0.6)
    ap.add_argument("--policy", default="clinical", choices=["clinical", "randomized_safe"])
    ap.add_argument("--sweep", action="store_true", help="sweep trial fidelity 0..0.9")
    ap.add_argument("--out", default="results")
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    ranker, df, summary = run(a.n, a.fidelity, a.policy, a.seed, a.n_test)
    ranker.save(str(out / "ranker.joblib"))
    (out / "summary.json").write_text(json.dumps({k: float(v) for k, v in summary.items()}, indent=2))
    sub = subgroup_table(df)
    sub.to_csv(out / "subgroups.csv", index=False)
    print(json.dumps({k: round(float(v), 4) for k, v in summary.items()}, indent=2))
    print(sub.round(4).to_string(index=False))

    if a.sweep:
        rows = []
        for f in [0.0, 0.2, 0.4, 0.6, 0.8, 0.9]:
            _, _, s = run(a.n, f, a.policy, a.seed, a.n_test)
            rows.append({"trial_fidelity": f, **{k: float(v) for k, v in s.items()}})
            print("fidelity", f, "model_best3_regret", round(s["model_best3_regret"], 4),
                  "always_semi_regret", round(s["always_semi_regret"], 4))
        pd.DataFrame(rows).to_csv(out / "fidelity_sweep.csv", index=False)


if __name__ == "__main__":
    main()
